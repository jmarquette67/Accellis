# How to use this starter hardening pack

1) In GitHub: open your repo → Add file → Upload files → drag the contents of this pack to the root.
2) Commit to `main`. GitHub Actions will run automatically.
3) Check: Actions tab → CodeQL, Semgrep, CI.
4) Fix issues as they appear in PR comments or the Actions logs.
